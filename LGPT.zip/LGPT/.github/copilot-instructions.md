# Library Management System - AI Agent Instructions

## Project Overview
This is a PHP-based Library Management System (LGPT) designed to run on XAMPP. The system follows a traditional multi-user web application architecture with distinct admin and user interfaces.

## Architecture

### Core Components
- **Authentication System**: Session-based (`session_start()` in entry points)
- **Database Layer**: MySQL via mysqli, configured in `includes/config.php`
- **User Roles**: Admin and regular users with separate interfaces
  - Admin interface: `/admin/*`
  - User interface: `/user/*`

### Key Directories
- `/admin`: Administration dashboard and management functions
- `/user`: User-facing features (book search, issue management)
- `/includes`: Core configuration and setup files
- `/css`: Styling (single stylesheet approach)

## Development Workflows

### Local Setup
1. Requires XAMPP with PHP and MySQL
2. Project should be placed in `htdocs/LGPT/`
3. Database configuration is managed in `includes/config.php`
4. Initial setup runs through `includes/db_setup.php`

### Database Patterns
- Direct mysqli queries (no ORM)
- SQL queries follow consistent date formatting:
  ```php
  DATE_FORMAT(column, '%d-%m-%Y') as formatted_column_date
  ```

### Code Conventions

#### PHP Patterns
- Session validation at entry points:
  ```php
  session_start();
  require_once '../includes/config.php';
  if (!isset($_SESSION['user_id'])) {
      header("Location: ../login.php");
      exit();
  }
  ```
- Direct database queries with error checking
- URL-based navigation with header redirects

#### Security Practices
- Session-based authentication
- Role-based access control (admin/user)
- SQL injection prevention through proper query construction

## Integration Points
- Book issue system connects user and admin workflows
- Status tracking system: pending → approved → returned
- Cross-module communication via database state changes

## Development Guidelines
1. Maintain session checks at entry points
2. Follow existing date formatting patterns
3. Use the centralized stylesheet in `/css/style.css`
4. Implement proper access controls for new features
