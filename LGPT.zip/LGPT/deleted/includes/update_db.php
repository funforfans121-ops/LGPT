<?php
// Add requested_on column and modify the issue date behavior
require_once 'config.php';

// First, add the requested_on column if it doesn't exist
$sql = "ALTER TABLE book_issues 
        ADD COLUMN IF NOT EXISTS requested_on DATE DEFAULT NULL AFTER user_id";
mysqli_query($conn, $sql);

// Update existing records to set requested_on to created_at date
$sql = "UPDATE book_issues 
        SET requested_on = created_at 
        WHERE requested_on IS NULL";
mysqli_query($conn, $sql);

// Update issue_date to be NULL by default
$sql = "ALTER TABLE book_issues 
        MODIFY issue_date DATE DEFAULT NULL";
mysqli_query($conn, $sql);

// Update return_date to be NULL by default
$sql = "ALTER TABLE book_issues 
        MODIFY return_date DATE DEFAULT NULL";
mysqli_query($conn, $sql);

// Update existing approved records
$sql = "UPDATE book_issues 
        SET return_date = DATE_ADD(issue_date, INTERVAL 7 DAY) 
        WHERE status = 'approved' AND issue_date IS NOT NULL";
mysqli_query($conn, $sql);

echo "Database updated successfully!";
?>
