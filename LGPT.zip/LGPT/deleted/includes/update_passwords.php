<?php
require_once 'config.php';

// Update admin password to MD5
mysqli_query($conn, "UPDATE users SET password = md5('admin123') WHERE username = 'admin'");

// Update test user passwords to MD5
$test_users = [
    'john_doe' => 'password123',
    'jane_smith' => 'password123',
    'bob_wilson' => 'password123',
    'alice_jones' => 'password123',
    'sam_brown' => 'password123'
];

foreach ($test_users as $username => $password) {
    $md5_password = md5($password);
    mysqli_query($conn, "UPDATE users SET password = '$md5_password' WHERE username = '$username'");
}

echo "All passwords have been updated to MD5 encryption.";
?>
