<?php
require_once 'config.php';

// Read the SQL file
$sql = file_get_contents('dummy_data.sql');

// Split into individual queries
$queries = explode(';', $sql);

$success = true;
$errors = [];

// Execute each query
foreach ($queries as $query) {
    $query = trim($query);
    if (!empty($query)) {
        if (!mysqli_query($conn, $query)) {
            $success = false;
            $errors[] = mysqli_error($conn);
        }
    }
}

if ($success) {
    echo "Dummy data imported successfully!";
} else {
    echo "Error importing dummy data:<br>";
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}
?>
