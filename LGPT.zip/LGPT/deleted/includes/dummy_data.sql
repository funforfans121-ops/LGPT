-- Dummy Categories
INSERT INTO categories (name) VALUES 
('Fiction'),
('Science Fiction'),
('Mystery'),
('Biography'),
('History'),
('Computer Science'),
('Philosophy'),
('Poetry'),
('Self-Help'),
('Business');

-- Dummy Authors
INSERT INTO authors (name) VALUES 
('J.K. Rowling'),
('George R.R. Martin'),
('Stephen King'),
('Jane Austen'),
('Ernest Hemingway'),
('Agatha Christie'),
('Mark Twain'),
('Charles Dickens'),
('Robert Martin'),
('Dale Carnegie');

-- Dummy Location Racks
INSERT INTO location_racks (name) VALUES 
('Floor 1 - Rack A1'),
('Floor 1 - Rack A2'),
('Floor 1 - Rack B1'),
('Floor 1 - Rack B2'),
('Floor 2 - Rack C1'),
('Floor 2 - Rack C2'),
('Floor 2 - Rack D1'),
('Floor 2 - Rack D2'),
('Reference Section - R1'),
('Special Collection - S1');

-- Dummy Books
INSERT INTO books (title, category_id, author_id, rack_id, isbn, quantity, available_quantity) VALUES 
('Harry Potter and the Philosopher''s Stone', 1, 1, 1, '9780747532699', 5, 3),
('A Game of Thrones', 2, 2, 1, '9780553103540', 4, 2),
('The Shining', 1, 3, 2, '9780385121675', 3, 3),
('Pride and Prejudice', 1, 4, 2, '9780141439518', 4, 4),
('The Old Man and the Sea', 1, 5, 3, '9780684801223', 3, 2),
('Murder on the Orient Express', 3, 6, 3, '9780007119318', 4, 3),
('The Adventures of Tom Sawyer', 1, 7, 4, '9780143039563', 3, 3),
('Great Expectations', 1, 8, 4, '9780141439563', 3, 2),
('Clean Code', 6, 9, 5, '9780132350884', 5, 4),
('How to Win Friends and Influence People', 9, 10, 5, '9780671027032', 4, 3),
('The Art of Computer Programming', 6, 9, 6, '9780201896831', 2, 2),
('Digital Fortress', 3, 3, 6, '9780312944926', 3, 3),
('The Da Vinci Code', 3, 3, 7, '9780385504201', 4, 4),
('A Brief History of Time', 5, 1, 7, '9780553380163', 3, 3),
('The Alchemist', 1, 2, 8, '9780062315007', 4, 4);

-- Dummy Users (passwords are 'password123')
INSERT INTO users (username, password, email, full_name, role, status) VALUES 
('john_doe', 'password123', 'john@example.com', 'John Doe', 'user', 'active'),
('jane_smith', 'password123', 'jane@example.com', 'Jane Smith', 'user', 'active'),
('bob_wilson', 'password123', 'bob@example.com', 'Bob Wilson', 'user', 'active'),
('alice_jones', 'password123', 'alice@example.com', 'Alice Jones', 'user', 'disabled'),
('sam_brown', 'password123', 'sam@example.com', 'Sam Brown', 'user', 'active');

-- Dummy Book Issues (mix of different statuses and dates)
INSERT INTO book_issues (book_id, user_id, issue_date, return_date, actual_return_date, fine, status, created_at) VALUES 
(1, 1, '2025-07-01', '2025-07-15', '2025-07-14', 0.00, 'returned', '2025-07-01 10:00:00'),
(2, 1, '2025-07-20', '2025-08-03', NULL, 0.00, 'approved', '2025-07-20 11:00:00'),
(3, 2, '2025-07-15', '2025-07-29', '2025-08-05', 7.00, 'returned', '2025-07-15 14:30:00'),
(4, 2, '2025-08-01', '2025-08-15', NULL, 0.00, 'approved', '2025-08-01 09:15:00'),
(5, 3, '2025-08-10', '2025-08-24', NULL, 0.00, 'pending', '2025-08-10 16:45:00'),
(6, 1, '2025-08-11', '2025-08-25', NULL, 0.00, 'pending', '2025-08-11 10:30:00'),
(7, 4, '2025-07-01', '2025-07-15', NULL, 0.00, 'rejected', '2025-07-01 13:20:00'),
(8, 5, '2025-08-05', '2025-08-19', NULL, 0.00, 'approved', '2025-08-05 15:10:00'),
(9, 3, '2025-07-10', '2025-07-24', '2025-07-23', 0.00, 'returned', '2025-07-10 11:45:00'),
(10, 2, '2025-08-11', '2025-08-25', NULL, 0.00, 'pending', '2025-08-11 09:00:00');
